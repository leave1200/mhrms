<?= $this->extend('backend/layout/auth-layout') ?>
<?= $this->section('content') ?>

-------auth content here---------

<?= $this->endSection()?>
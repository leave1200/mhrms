<div class="footer-wrap pd-20 mb-20 card-box">
					Develop by Mark Rebb Barsaga - DeskApp template
					<a href="https://github.com/dropways" target="_blank"
						></a
					>
				</div>
<?= $this->extend('backend/layout/pages-layout') ?>
<?= $this->section('content') ?>

-------PAge content here---------

<?= $this->endSection()?>

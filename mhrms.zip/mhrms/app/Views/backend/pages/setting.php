<?= $this->extend('backend/layout/pages-layout') ?>
<?= $this->section('content') ?>

-------Settings content here---------

<?= $this->endSection()?>
